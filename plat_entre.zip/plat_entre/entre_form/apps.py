from django.apps import AppConfig


class EntreFormConfig(AppConfig):
    name = 'entre_form'
